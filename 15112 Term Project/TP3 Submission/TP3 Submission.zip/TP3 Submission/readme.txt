
1: This is my 15112 term project, SpyRing!
   It's a 1v1 turn based game you can play against another person
   or a minimax AI. You can move around the world map, do actions,
   and hunt down your opponent. Last spy standing wins. 

2: To run, use the main src file. If the images don't work or 
   are not found in the file directory, you can upload 
   them into CS Academy, then replace the links with the ones CS
   Academy provides and run in Sandbox. No external modules are used
   besides cmu_graphics. Make sure to pip install it. 

3: No shortcut commands.
